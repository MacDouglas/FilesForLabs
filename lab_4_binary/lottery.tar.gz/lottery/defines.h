#pragma once

#define let const auto


