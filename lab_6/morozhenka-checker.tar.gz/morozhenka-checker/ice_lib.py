import requests

import checklib

wraps_down = checklib.wraps_down

class CheckMachine:
    PORT = 7001

    @property
    def url(self):
        return "http://{}:{}".format(self.host, self.PORT)

    def __init__(self, host):
        self.host = host

    @wraps_down
    def register_service(self, password=None):
        username = checklib.rand_string(8)
        if not password:
            password = checklib.rand_string(32)
        r = requests.get(f'{self.url}/registerForm', params={'login': username, 'password': password}, timeout=10)
        checklib.check_response(r, 'Could not register')
        return username, password

    @wraps_down
    def login_in_service(self, login, password):
        login_url = f'{self.url}/loginForm'
        session = requests.Session()
        login_data = {
            'login': login,
            'password': password
        }
        r = session.get(url=login_url, params=login_data, allow_redirects=False, timeout=10)
        checklib.assert_eq(r.status_code, 302, "Cant't login in service")
        return session

    @wraps_down
    def add_icecream(self, session, text):
        add_url = f'{self.url}/addForm'
        r = session.get(url=add_url, params={'icecream': text}, timeout=10)
        checklib.check_response(r, 'Could not add icecream')
        return checklib.get_text(r, 'Could not add icecream')

    @wraps_down
    def get_my_icecreams(self, session):
        my_url = f'{self.url}/icecreams'
        r = session.get(url=my_url, timeout=10)
        checklib.check_response(r, 'Could not get user icecreams')
        return checklib.get_text(r, 'Could not get user icecreams')

    @wraps_down
    def get_index(self):
        r = requests.get(f'{self.url}/', timeout=10)
        checklib.check_response(r, 'Could not get main page')
        return checklib.get_text(r, 'Could not get main page')

    @wraps_down
    def get_login_page(self):
        r = requests.get(f'{self.url}/login.html', timeout=10)
        checklib.check_response(r, 'Could not get login page')
        return checklib.get_text(r, 'Could not get login page')

    @wraps_down
    def get_register_page(self):
        r = requests.get(f'{self.url}/register.html', timeout=10)
        checklib.check_response(r, 'Could not get register page')
        return checklib.get_text(r, 'Could not get register page')

    @wraps_down
    def get_add_page(self, sess):
        r = sess.get(f'{self.url}/add.html', timeout=10)
        checklib.check_response(r, 'Could not get add icecream page')
        return checklib.get_text(r, 'Could not get add icecream page')

    @wraps_down
    def get_last_users(self):
        r = requests.get(f'{self.url}/lastusers', timeout=10)
        checklib.check_response(r, 'Could not get last users')
        return checklib.get_text(r, 'Could not get last users')
