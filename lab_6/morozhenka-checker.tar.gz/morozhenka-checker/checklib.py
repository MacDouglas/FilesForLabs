#!/usr/bin/env python3

import requests
import sys
import string
import random

from typing import Optional

### Common checker stuffs ###

class WithExitCode(Exception):
    code: int

    def __init__(self, msg_opt: Optional[str] = None) -> None:
        msg = ""
        name = self.__class__.__name__
        if msg_opt is not None:
            msg = name + ": " + msg_opt
        else:
            msg = name
        super().__init__(msg)
class Corrupt(WithExitCode):
    code = 102
class Mumble(WithExitCode):
    code = 103
class Down(WithExitCode):
    code = 104
class CheckerError(WithExitCode):
    code = 110

class Color:
    value: bytes

    @classmethod
    def print(cls, msg: str) -> None:
        sys.stdout.buffer.write(b"\x1b[01;" + cls.value + b"m")
        sys.stdout.buffer.flush()
        print(msg)
        sys.stdout.buffer.write(b"\x1b[m")
        sys.stdout.buffer.flush()
class Red(Color):
    value = b"31"
class Green(Color):
    value = b"32"

def rand_string(length: int = 16) -> str:
    letters = string.ascii_letters + string.digits
    name = "".join(random.choice(letters) for _ in range(length))
    return name


def assert_in(x, xs, msg, exception=Mumble):
    if x not in xs:
        raise exception(msg)

def assert_eq(x, y, msg, exception=Mumble):
    if not (x == y):
        raise exception(msg)

def check_response(r: requests.Response, msg, exception=Mumble):
    if r.status_code != 200:
        raise exception(msg)

def get_text(r: requests.Response, msg, exception=Mumble):
    if not r.text:
        raise exception(msg)
    return r.text

def wraps_down(f):
    def r(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except requests.exceptions.ConnectionError as e:
            raise checklib.Down(str(e))
    return r
