#!/usr/bin/env python3

import argparse
import sys
import requests
from typing import Callable

from ice_lib import CheckMachine
import sploit
from checklib import *

### Logic starts here ###

def check_html_page(page):
    assert_in("/register.html", page, "No register link")
    assert_in("/login.html", page, "No login link")
    assert_in("/add.html", page, "No add link")
    assert_in("/icecreams", page, "No icecreams link")
    assert_in("/lastusers", page, "No lastusers link")


def put(host: str, flag_id: str, flag: str, vuln: str) -> None:
    cm = CheckMachine(host)

    register_resp = cm.get_register_page()
    assert_in("registerForm", register_resp, "No registration form")
    check_html_page(register_resp)
    password = None
    if vuln == "2":
        password = flag
    login, password = cm.register_service(password=password)

    login_resp = cm.get_login_page()
    check_html_page(login_resp)
    assert_in("loginForm", login_resp, "No login form")
    sess = cm.login_in_service(login, password)

    resp = cm.get_add_page(sess)
    check_html_page(resp)
    assert_in("addForm", resp, "No add form")
    icecream_name = rand_string(20)
    if vuln == "1":
        icecream_name = flag
    resp = cm.add_icecream(sess, icecream_name)
    assert_in("Icecream added", resp, "Failed to add icecream")


def get(host, flag_id, flag, vuln):
    cm = CheckMachine(host)
    login, password = flag_id.split(":")
    login_resp = cm.get_login_page()
    check_html_page(login_resp)
    assert_in("loginForm", login_resp, "No login form")
    sess = cm.login_in_service(login, password)
    my_icecreams = cm.get_my_icecreams(sess)
    assert_in(
        flag,
        my_icecreams,
        "Failed to get user icecreams",
        status=Corrupt,
    )


def check(host):
    cm = CheckMachine(host)

    index_resp = cm.get_index()
    check_html_page(index_resp)

    register_resp = cm.get_register_page()
    assert_in("registerForm", register_resp, "No registration form")
    check_html_page(register_resp)
    login, password = cm.register_service()

    last_user_resp = cm.get_last_users()
    assert_in(login, last_user_resp, "Failed to find last user")

    login_resp = cm.get_login_page()
    check_html_page(login_resp)
    assert_in("loginForm", login_resp, "No login form")
    sess = cm.login_in_service(login, password)

    resp = cm.get_add_page(sess)
    check_html_page(resp)
    assert_in("addForm", resp, "No add form")
    icecream_name = rand_string(20)
    resp = cm.add_icecream(sess, icecream_name)
    assert_in("Icecream added", resp, "Failed to add icecream")
    my_icecreams = cm.get_my_icecreams(sess)
    assert_in(icecream_name, my_icecreams, "Failed to get user icecreams")


def attack(host: str) -> None:
    sploit.attack(host, CheckMachine.PORT)


def run(host: str) -> None:
    for _ in range(5):
        check(host)
        Green.print("check")
    try:
        attack(host)
        Red.print("attack")
    except sploit.AttackError:
        Green.print("attack")


def main(args: argparse.Namespace, usage: Callable[[], None]) -> int:

    try:
        if args.command == "check":
            check(args.host)
        elif args.command == "put":
            put(args.host, args.flag_id, args.flag, args.vuln)
        elif args.command == "get":
            get(args.host, args.flag_id, args.flag, args.vuln)
        elif args.command == "run":
            run(args.host)
        elif args.command == "attack":
            attack(args.host)
        else:
            print(f"Incorrect command: {args.command}")
            usage()
            return CheckerError.code
        # if not thrown, everything is ok
        return 101

    except WithExitCode as e:
        Red.print(str(e))
        return e.code
    except sploit.AttackError as e:
        Red.print("AttackError: " + str(e))
        return 1
    except requests.exceptions.ConnectionError as e:
        Red.print(str(e))
        return Down.code

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Checker for trackbattle")
    parser.add_argument("command", metavar="COMMAND", type=str, help="run|check|put|get|attack")
    parser.add_argument("host", metavar="HOST", type=str, help="address of host (you probably want 'localhost')")
    parser.add_argument("flag", metavar="FLAG", type=str, help="flag to put or to get. Only required for those commands", nargs="?", default="")
    parser.add_argument("flag_id", metavar="FLAG_ID", type=str, help="Noone knows what this is, but it's used by upstream libraries", nargs="?", default="")
    parser.add_argument("vuln", metavar="VULN", type=str, help="Noone knows what this is, but it's used by upstream libraries", nargs="?", default="")
    args = parser.parse_args()

    sys.exit(main(args, parser.print_help))
