# Требования для запуска

1. requests. Устанавливается через `zypper install python3-requests` или `pip3 install requests`
2. exiftool. Устанавливается через `zypper install exiftool`
